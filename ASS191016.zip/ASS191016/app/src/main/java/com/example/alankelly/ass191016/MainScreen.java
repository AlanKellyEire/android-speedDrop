package com.example.alankelly.ass191016;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alankelly.ass191016.R;

import java.text.DecimalFormat;

public class MainScreen extends AppCompatActivity {

    private EditText noConvert, dataToPass;
    private View grid;
    //public final static String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("MyApp","created");
        setContentView(R.layout.activity_main_screen);
        grid = (View) findViewById(R.id.grid);

        dataToPass = (EditText)findViewById(R.id.dataToPass);

        Button convert = (Button) findViewById(R.id.convertButton);
        convert.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                noConvert = (EditText)findViewById(R.id.convertInput);
                String s = noConvert.getText().toString();
                if (s.isEmpty()) {
                    Context context = getApplicationContext();
                    Toast.makeText(context, "Please enter an amount", Toast.LENGTH_SHORT).show();
                    grid.setVisibility(View.INVISIBLE);
                    return;
                }
                double conAns = Double.parseDouble(s);
                System.out.print(conAns);
                conAns = conAns / 3.6;
                Log.d("MyApp", Double.toString(conAns) + "     converted");
                String result = String.format("%.2f", conAns);
                TextView convertAns = (TextView) findViewById(R.id.gridConResult);
                convertAns.setText(result + " M/S");
                grid.setVisibility(View.VISIBLE);
            }
        });
    }

    /** Called when the user clicks the Send button */
    public void sendMessageSecondAct(View view) {
        Intent intent = new Intent(this, secondActivity.class);
        EditText editText = (EditText) findViewById(R.id.dataToPass);
        String message = editText.getText().toString();
        Log.d("MyApp",message);
        intent.putExtra("blank", message);
        startActivity(intent);
        Log.d("MyApp","2nd created");
    }

    public void sendMessageThirdAct(View view) {
        Intent intent = new Intent(this, thirdActivity.class);
        startActivity(intent);
        Log.d("MyApp","3rd created");
    }

//    /** Called when the user clicks the Send button */
//    public void sendMessage(View view) {
//        // Do something in response to button
//        Intent intent = new Intent(this, secondActivity.class);
//        EditText editText = (EditText) findViewById(R.id.dataToPass);
//        String message = dataToPass.getText().toString();
//        Log.d("MyApp",message);
//        //secondLayoutText.setText(message);
//        //intent.putExtra(EXTRA_MESSAGE, message);
//        intent.putExtra(dataToPass.getText().toString(), message);
//        startActivity(intent);
//
//        Log.d("MyApp","2nd created");
//    }

}
