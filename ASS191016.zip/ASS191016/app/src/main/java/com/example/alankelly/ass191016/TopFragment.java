package com.example.alankelly.ass191016; /**
 * Created by AlanKelly on 28/10/2016.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.example.alankelly.ass191016.MainScreen;
import com.example.alankelly.ass191016.R;
import com.example.alankelly.ass191016.secondActivity;
import com.example.alankelly.ass191016.thirdActivity;


public class TopFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.top_fragment, container, false);

        return view;
    }

    TopFragmentListener activityCommander;

    public interface TopFragmentListener{
        public void createClick(String top, String bottom);
    }

//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        try{
//            activityCommander = (TopFragmentListener) activity;
//        }
//
//    }

    public void sendMessageSecondAct(View view) {
//        Intent intent = new Intent(getActivity(), secondActivity.class);
//        EditText editText = (EditText) view.findViewById(R.id.dataToPass);
//        String message = editText.getText().toString();
//        Log.d("MyApp",message);
//        intent.putExtra("blank", message);
//        startActivity(intent);
//        Log.d("MyApp","2nd created");

        Intent i = new Intent(getActivity(), secondActivity.class);

        i.putExtra("key","value");
        startActivity(i);
    }

    public void sendMessageThirdAct(View view) {
        Intent intent = new Intent(getActivity(), thirdActivity.class);
        startActivity(intent);
        Log.d("MyApp","3rd created");
    }

}